package patientPackage;

public class Patient {

		String firstName;
		String middleName;
		String lastName;
		String address;
		String city;
		String state;
		String zip;
		String phoneNum;
		String emergencyName;
		String emergencyPhone;
	
	//default constructor
	public Patient() {
		
	}

	
	public Patient(String firstName, String middleName, String lastName) {
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;

	}
	
	public Patient (String firstName, String middleName, String lastName, String address, String city, String state, String zip, String phoneNum, String emergencyName, String emergencyPhone) {
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.address = address;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.phoneNum = phoneNum;
		this.emergencyName = emergencyName;
		this.emergencyPhone = emergencyPhone;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getaddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state; 
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getZip() {
		return zip; 
	}
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public String getEmergencyName() {
		return emergencyName;
	}
	public void setEmergencyName(String emergencyName) {
		this.emergencyName = emergencyName;
	}
	public String getEmergencyPhone() {
		return emergencyPhone;
	}
	public void setEmergencyPhone(String emergencyPhone) {
		this.emergencyPhone = emergencyPhone;
	}
	
	private String buildFullName () {
		return firstName + " " + middleName + " " + lastName;
	}
	
	private String buildAddress () {
		return address + " " + city + " " + state + " " + zip;
	}
	private String buildEmergencyContact () {
		return emergencyName + " " + emergencyPhone;
	}
	public String toString() {
		return "\n" + "  " + "Patient name: " + buildFullName() + "\n"
				+ "  " + "Patient address: " + buildAddress() + "\n" 
				+ "  " + "Patient phone number: " + phoneNum + "\n"
				+ "  " + "Patient's emergency contact: " + buildEmergencyContact()
				+ "\n"; 
	}
}
