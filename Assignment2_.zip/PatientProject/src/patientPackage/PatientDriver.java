package patientPackage;

import java.util.Scanner;

public class PatientDriver {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
	
		System.out.println("Enter patient's first name? ");
		String firstName = keyboard.nextLine();
		
		System.out.println("Enter patient's middle name? ");
		String middleName = keyboard.nextLine();
		
		System.out.println("Enter patient's last name? ");
		String lastName = keyboard.nextLine();
		
		System.out.println("Enter patient's street address? ");
		String address = keyboard.nextLine();
		
		System.out.println("Enter patient's city? ");
		String city = keyboard.nextLine();
		
		System.out.println("Enter patient's state? ");
		String state = keyboard.nextLine();
		
		System.out.println("Enter patient's zip code? ");
		String zip = keyboard.nextLine();
		
		System.out.println("Enter the patient's phone number? ");
		String phoneNum = keyboard.nextLine();
		
		System.out.println("Enter the emergency contacts name? ");
		String emergencyName = keyboard.nextLine();
		
		System.out.println("Enter the emergency contacts phone number? ");
		String emergencyPhone = keyboard.nextLine();
		
		System.out.println("Enter the date: ");
		String date = keyboard.nextLine();
		
		Patient patient = new Patient (firstName, middleName, lastName, address, city, state, zip, phoneNum, emergencyName, emergencyPhone);
		
		Procedure PhysicalExam = new Procedure ("Physical Exam", date, "Dr. John", 0.0);
		Procedure X_Ray = new Procedure ("X-Ray", date, "Dr. John", 0.0);
		Procedure BloodTest = new Procedure ("Blood Test", date, "Dr. John", 0.0); 
		
		
		displayPatient(patient);
		displayProcedure(PhysicalExam);
		displayProcedure(X_Ray);
		displayProcedure(BloodTest);
		
		double totalCharges = calculateTotalCharges(PhysicalExam, X_Ray, BloodTest);
	
		System.out.println(String.format("%-14s$%,.2f","Total charges: ",totalCharges));
		
		keyboard.close();
		
		System.out.println("\n" + "Student name: Isabel Saffell");
		System.out.println("MC# = 21201549");
		System.out.println("Due date: 07/01");
		
		}
	
	
	
	public static void displayPatient(Patient patient) {
		System.out.println("Patient information: " + patient.toString());
	}
	public static void displayProcedure (Procedure procedure) {
		System.out.println("\t" + "Procedure: " + procedure.getProcedureName());
		System.out.println("\t" + "Procedure date: " + procedure.getProcedureDate());
		System.out.println("\t" + "Practitioner: " + procedure.getPractitioner());
		System.out.println("\t" + "Charges: " + procedure.getCharges() + "\n");
		
	}
	public static double calculateTotalCharges(Procedure PhysicalExam, Procedure X_Ray, Procedure BloodTest) {
		double totalCharges = 0;
		totalCharges += PhysicalExam.getCharges();
		totalCharges += X_Ray.getCharges();
		totalCharges += BloodTest.getCharges();
		
		return totalCharges;
	}

}
