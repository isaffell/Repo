package patientPackage;

public class Procedure {
	String ProcedureName;
	String ProcedureDate;
	String Practitioner;
	Double Charges;
	
	public Procedure() {
		
	}
	
	public Procedure(String ProcedureName, String ProcedureDate) {
		this.ProcedureName = ProcedureName;
		this.ProcedureDate = ProcedureDate;
		
	}
	
	public Procedure (String ProcedureName, String ProcedureDate, String Practitioner, Double Charges) {
		this.ProcedureName = ProcedureName;
		this.ProcedureDate = ProcedureDate;
		this.Practitioner = Practitioner; 
		this.Charges = Charges;
	}
	
	public String getProcedureName() {
		return ProcedureName;
	}
	
	public void setProcedureName(String ProcedureName) {
		this.ProcedureName = ProcedureName;
	}
	
	public String getProcedureDate() {
		return ProcedureDate;
	}
	
	public void setProcedureDate(String ProcedureDate) {
		this.ProcedureDate = ProcedureDate;
	}
	
	public String getPractitioner() {
		return Practitioner;
	}
	
	public void setPractitioner(String Practitioner) {
		this.Practitioner = Practitioner;
	}
	
	public Double getCharges() {
		return Charges;
	}
	public void setCharges(Double Charges) {
		this.Charges = Charges;
	}
	
	public String toString() {
		return "Procedure name: " + ProcedureName + "\n"
				+ "Procedure date: " + ProcedureDate + "\n" 
				+ "Practitioner name: " + Practitioner 
				+ "Charges: " + Charges;
		
	}
	
	
}

